import XCTest
@testable import Configurations

final class ConfigurationsViewTests: XCTestCase {
    func testExample() {
    }

    static var allTests = [
        ("testExample", testExample),
    ]
}

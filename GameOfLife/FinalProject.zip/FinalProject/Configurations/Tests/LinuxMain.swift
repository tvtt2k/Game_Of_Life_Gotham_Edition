import XCTest

import ConfigurationsViewTests

var tests = [XCTestCaseEntry]()
tests += ConfigurationsViewTests.allTests()
XCTMain(tests)

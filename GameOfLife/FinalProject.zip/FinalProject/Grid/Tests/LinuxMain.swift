import XCTest

import GridTests

var tests = [XCTestCaseEntry]()
tests += GridTests.allTests()
XCTMain(tests)

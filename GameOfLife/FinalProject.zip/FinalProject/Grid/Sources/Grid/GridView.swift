// GridView.swift
// Modified to include animation for grid cells and rotation of the grid

import ComposableArchitecture
import GameOfLife
import SwiftUI
import Theming

public struct GridView: View {
    @Bindable var store: StoreOf<GridModel>

    public init(store: StoreOf<GridModel>) {
        self.store = store
    }

    public var body: some View {
        WithViewStore(store, observe: { $0 }) { store in
            GeometryReader { outer in
                ZStack {

                    GridLines(
                        rows: store.grid.size.rows,
                        cols: store.grid.size.cols,
                        lineWidth: store.lineWidth
                    )

                    GridCells(
                        rows: store.grid.size.rows,
                        cols: store.grid.size.cols,
                        lineWidth: store.lineWidth,
                        inset: store.inset,
                        states: store.grid
                    )
                    .transition(.scale(scale: 0.8, anchor: .center))
                    .rotationEffect(Angle(degrees: store.rotation))
                    .opacity(store.grid.size.rows % 2 == 0 ? 1.0 : 0.5)
                    .animation(
                        .easeInOut(duration: 1.0).repeatCount(3, autoreverses: true),
                        value: store.grid
                    )

                    GridTouchView(
                        store: store
                    )
                }
            }
            .aspectRatio(1.0, contentMode: .fit)
            .padding(store.lineWidth / 2.0)
            .background(Color("gridBackground", bundle: Theming.bundle))
            .clipped()
            .padding(4.0)
            .padding(20.0)
            .rotationEffect(Angle(degrees: store.rotation)) // Add rotation to the entire grid
            .animation(
                .easeInOut(duration: 2.0).repeatForever(autoreverses: false),
                value: store.rotation
            )
        }
    }
}

#Preview {
    let rows = 5
    let cols = 5
    let lineWidth = 16.0
    let inset = 8.0

    GridView(
        store: .init(
            initialState: .init(
                lineWidth: lineWidth,
                inset: inset,
                grid: .init(rows, cols, Grid.Initializers.random)
            ),
            reducer: GridModel.init
        )
    )
}



import XCTest

import SimulationViewTests

var tests = [XCTestCaseEntry]()
tests += SimulationViewTests.allTests()
XCTMain(tests)

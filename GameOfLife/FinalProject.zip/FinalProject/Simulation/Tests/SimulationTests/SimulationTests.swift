import XCTest
import ComposableArchitecture
import Combine
import Grid
import GameOfLife
@testable import Simulation

final class SimulationViewTests: XCTestCase {
    static var allTests = [
        ("testExample", testResetTicks),
    ]

    func testResetTicks() {
    }
}

import XCTest
@testable import Statistics

final class StatisticsViewTests: XCTestCase {
    func testExample() {
    }

    static var allTests = [
        ("testExample", testExample),
    ]
}

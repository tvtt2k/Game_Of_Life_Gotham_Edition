import XCTest

import StatisticsViewTests

var tests = [XCTestCaseEntry]()
tests += StatisticsViewTests.allTests()
XCTMain(tests)

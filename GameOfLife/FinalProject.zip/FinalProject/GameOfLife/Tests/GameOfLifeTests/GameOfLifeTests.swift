import XCTest
@testable import GameOfLife

final class GameOfLifeTests: XCTestCase {
    func testExample() {
    }

    static var allTests = [
        ("testExample", testExample),
    ]
}

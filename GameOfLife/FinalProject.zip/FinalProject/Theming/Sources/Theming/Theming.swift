//
//  Theming.swift
//  Theming
//
//  Created by Van Simmons on 11/20/24.
//
import Foundation

public struct Theming {
    public static let bundle: Bundle = Bundle.module
}

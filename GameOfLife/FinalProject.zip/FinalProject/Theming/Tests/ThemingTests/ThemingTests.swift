import XCTest
@testable import Theming

final class ThemingTests: XCTestCase {
    func testExample() throws {
    }
}

import XCTest

import ConfigurationViewTests

var tests = [XCTestCaseEntry]()
tests += ConfigurationViewTests.allTests()
XCTMain(tests)

import XCTest
@testable import Configuration

final class ConfigurationViewTests: XCTestCase {
    func testExample() {
    }

    static var allTests = [
        ("testExample", testExample),
    ]
}
